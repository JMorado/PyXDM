# Horton Proatom Database for Hirshfeld Partition Schemes

## Generate Input Files

```bash
horton-atomdb.py input orca 1,5-9,14-17,35 template.orca
```

## Run ORCA Calculations

Edit the ORCA path in `./run_orca.sh`, make it executable, and run:

```bash
chmod +x run_orca.sh
./run_orca.sh
```

## Create ProAtom Database

```bash
horton-atomdb.py convert
```

